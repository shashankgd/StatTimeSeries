from matplotlib import pyplot as p
from matplotlib import style


x=[4,5,10]
y=[2,6,90]

p.bar(x,y,label="abc",color='b')
p.bar(y,x,label="def",color='g')

p.title("Info")
p.xlabel("Xaxis")
p.ylabel("Yaxis")
p.legend()
p.grid(True,color='k')
p.show()
