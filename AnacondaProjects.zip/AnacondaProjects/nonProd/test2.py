import numpy as np


print(help(np))