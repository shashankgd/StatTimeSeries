from nonProd.test10 import  Parent
class child2(Parent):
    pass

c=child2()
c.Parent()