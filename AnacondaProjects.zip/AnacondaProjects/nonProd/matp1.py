from matplotlib import pyplot as p
from matplotlib import style

style.use("ggplot")

x=[4,5,10]
y=[2,6,90]

p.plot(x,y,'g',label="abc",linewidth=5)
p.plot(y,x,'b',label="def",linewidth=8)

p.title("Info")
p.xlabel("Xaxis")
p.ylabel("Yaxis")
p.legend()
p.grid(True,color='w')

p.show()
