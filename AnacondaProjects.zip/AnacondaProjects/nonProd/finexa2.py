import datetime as dt
import matplotlib.pyplot as plt
from matplotlib import style
import pandas as pd
import pandas_datareader.data as web
import sys
sys.path.insert(0,"C:\\Users\shaskhan\AppData\Local\Programs\Python\Python36-32\Lib\site-packages\mpl_finance-master")
import mpl_finance
import matplotlib.dates as mdates

style.use('ggplot')

df = pd.read_csv('tsla.csv', parse_dates=True, index_col=0)
df_ohlc = df['AdjClose'].resample('10D').ohlc()
df_volume = df['Volume'].resample('10D').sum()
df_ohlc = df_ohlc.reset_index()
df_ohlc['Date'] = df_ohlc['Date'].map(mdates.date2num)
fig = plt.figure()
ax1 = plt.subplot2grid((6,1), (0,0), rowspan=5, colspan=1)
ax2 = plt.subplot2grid((6,1), (5,0), rowspan=1, colspan=1,sharex=ax1)
ax1.xaxis_date()

mpl_finance.candlestick_ohlc(ax1, df_ohlc.values, width=2, colorup='g')

ax2.fill_between(df_volume.index.map(mdates.date2num),df_volume.values,0)
plt.show()