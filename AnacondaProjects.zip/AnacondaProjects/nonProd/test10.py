class Parent(object):
    def Parent(self):
        print("Parent")

    def Parent11(self):
        print("Parent11")


class Parent2(object):
    def Parent(self):
        print("Parent2")

class child(Parent):
    def child1(self):
        print("child1")


class child2(Parent2,Parent):
    def child1(self):
        print("child1")


if __name__=="__main__":

    print("Hello")