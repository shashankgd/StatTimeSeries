from functools import reduce
''''
#1 pandas.Series( data, index, dtype, copy)
# data ndarray, list, constants
# A series can be created using :
array
 dict 
 scalar value.


#2 pandas.DataFrame( data, index, columns, dtype, copy)

#data =  ndarray, series, map, lists, dict, constants and also another DataFrame
Dataframe can be created using :
Lists

data = [1,2,3,4,5]
df = pd.DataFrame(data)

data = [['Alex',10],['Bob',12],['Clarke',13]]
df = pd.DataFrame(data,columns=['Name','Age'])


dict

data = {'Name':['Tom', 'Jack', 'Steve', 'Ricky'],'Age':[28,34,29,42]}
df = pd.DataFrame(data)

data = {'Name':['Tom', 'Jack', 'Steve', 'Ricky'],'Age':[28,34,29,42]}
df = pd.DataFrame(data, index=['rank1','rank2','rank3','rank4'])

data = [{'a': 1, 'b': 2},{'a': 5, 'b': 10, 'c': 20}]
df = pd.DataFrame(data)

data = [{'a': 1, 'b': 2},{'a': 5, 'b': 10, 'c': 20}]
df = pd.DataFrame(data, index=['first', 'second'])


Series
Numpy ndarrays
Another DataFrame

'''

print("Helo")


n = int(input().strip())
assert 2<=n<=20

ans= ( list (map (lambda x : x *n ,range(1,11)) ) )
list(print(n," x ",range(1,11)[i-1]," = ",ans[i-1]) for i in  range(1,11))

T = int(input().strip())
assert 1<=T<=10
stringlist=[]
for i in range(T):
    S=input().strip()
    #assert 2<=len(S)<=1000
    print(len(S))

    stringlist.append(S)


for i in range(T):
    st=stringlist[i]
    ls=''
    rs=''

    for x in range(len(st)):
        if x%2==0:
            ls=ls+st[x]
        else:
            rs=rs+st[x]

    print(ls,"  ",rs)


