import nsepy
from datetime import date
import pandas as pd
import numpy as np
import csv
import pandas_datareader as web
import os


'''to be put in config file'''

user_ip_file="C:/Users/shaskhan/AnacondaProjects/am/finProduct/database/user_ip.csv"
feature="C:/Users/shaskhan/AnacondaProjects/am/finProduct/database/features.csv"





class ta(object):



    def read_user_ip_fname(self):
        #self.user_ip_data=dict(u.split(":") for u in  open(user_ip_file,'r').readline().replace("=",':').strip().split(","))
        self.user_ip_data=open(user_ip_file,'r').readline().strip()

        df = web.DataReader(self.user_ip_data)

        '''select columns that are essential'''
        self.dataset = df.loc[:,['Close','AdjClose','Volume','AdjVolume']]


    '''Calculate return'''

    def roi(self):
        dataset=self.dataset
        print(self.dataset, self.dataset[1:])
        #roi = (dataset[:-1] / dataset[1:].values - 1)



        daily_return = self.dataset.pct_change(1) # 1 for ONE DAY lookback
        monthly_return = self.dataset.pct_change(21) # 21 for ONE MONTH lookback
        annual_return = self.dataset.pct_change(252) # 252 for ONE YEAR lookback
        #print(roi)

    '''
    requests.exceptions.ConnectionError: ('Connection aborted.',
     LineTooLong('got more than 65536 bytes when reading header line',))
    
    
    dataset  = nsepy.get_history(symbol="NIFTY",
                        start=date(2018,3,29),
                        end=date(2018,3,30),
                        index=True)
    
    
    '''

a=ta()
a.roi()