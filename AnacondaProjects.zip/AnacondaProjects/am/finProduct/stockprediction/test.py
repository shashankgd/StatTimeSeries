import numpy as np
import csv
import pandas_datareader as web
import os
import datetime
from datetime import date


'''to be put in config file'''

user_ip_file="C:/Users/shaskhan/AnacondaProjects/am/finProduct/database/user_ip.csv"
feature="C:/Users/shaskhan/AnacondaProjects/am/finProduct/database/features.csv"





class ta(object):



    def read_user_ip_fname(self):
        user_ip_data=dict(u.split("=") for u in  open(user_ip_file,'r').readline().strip().split(","))
        args=user_ip_data.keys()
        print(user_ip_data)

print(web.DataReader(name='TSLA',data_source="quandl",start=date(2017,10,1),end=date(2017,11,30)))