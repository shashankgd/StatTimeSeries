import os


cd=os.getcwd()
db_path=os.path.join(cd,'database')
user_ip=os.path.join(db_path,'user_ip.csv')
features=os.path.join(db_path,'features.csv')
featuredata=os.path.join(db_path,'featuredata.csv')

