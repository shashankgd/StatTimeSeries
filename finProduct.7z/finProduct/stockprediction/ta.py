import nsepy
import datetime
from datetime import date
from dateutil.parser import parse
import pandas as pd
import numpy as np
import csv
import pandas_datareader as web
import os

print(os.path)


'''to be put in config file'''

user_ip_file="C:/Prgs/Code/mokshtech/am/finProduct/database/user_ip.csv"
feature="C:/Prgs/Code/mokshtech/am/finProduct/database/features.csv"





class ta(object):



    def read_user_ip_fname(self):
        self.user_ip_data=dict(u.split(":") for u in  open(user_ip_file,'r').readline().replace("=",':').strip().split(","))

        #print(datetime.datetime.strptime(self.user_ip_data['start'],'%Y-%m-%d'))
        #print(parse(self.user_ip_data['start']))

        d1=list(map(int,self.user_ip_data['start'].split("-")))
        self.user_ip_data['start']=(date(d1[0],d1[1],d1[2]))

        d2 = list(map(int, self.user_ip_data['end'].split("-")))
        self.user_ip_data['end'] = (date(d2[0], d2[1], d2[2]))


        print(self.user_ip_data)


        '''
        df = web.DataReader(self.user_ip_data)


    
    requests.exceptions.ConnectionError: ('Connection aborted.',
     LineTooLong('got more than 65536 bytes when reading header line',))
    
       '''
        df  = nsepy.get_history((for k,v in self.user_ip_data k=v)
        )

        '''select columns that are essential'''

        self.dataset = df.loc[:, ['Close', 'AdjClose', 'Volume', 'AdjVolume']]
        #print(self.dataset)



    '''Calculate return'''


    def roi(self):
        closedataset=self.dataset.loc[:,['Close']]
        roi = (closedataset / closedataset.values - 1)

        daily_return = self.dataset.pct_change(1)  # 1 for ONE DAY lookback
        monthly_return = self.dataset.pct_change(21)  # 21 for ONE MONTH lookback
        annual_return = self.dataset.pct_change(252)  # 252 for ONE YEAR lookback
        print(roi)


a=ta()
a.read_user_ip_fname()
a.roi()