import pandas as pd
import numpy as np
import itertools
from itertools import permutations
print("start")
a=[[1,3,5],[2,4,6],[7,9,11]]



df=pd.Series(list(itertools.product(*a)))
print(df)