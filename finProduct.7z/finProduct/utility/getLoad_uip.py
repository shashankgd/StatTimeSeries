import nsepy
from datetime import date
import pandas as pd

dataset_train  = pd.DataFrame(nsepy.get_history(symbol="NIFTY",
                    start=date(2018,1,1),
                    end=date(2018,4,6),
					index=True)).to_csv("C:/Prgs/Code/mokshtech/am/finProduct/utility/../database/stockpath.csv")


